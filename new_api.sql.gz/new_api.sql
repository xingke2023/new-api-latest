-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: new_api
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `abilities`
--

DROP TABLE IF EXISTS `abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `abilities` (
  `group` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `model` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `channel_id` bigint NOT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `priority` bigint DEFAULT '0',
  `weight` bigint unsigned DEFAULT '0',
  `tag` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`group`,`model`,`channel_id`),
  KEY `idx_abilities_channel_id` (`channel_id`),
  KEY `idx_abilities_priority` (`priority`),
  KEY `idx_abilities_weight` (`weight`),
  KEY `idx_abilities_tag` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abilities`
--

LOCK TABLES `abilities` WRITE;
/*!40000 ALTER TABLE `abilities` DISABLE KEYS */;
INSERT INTO `abilities` VALUES ('default','claude-opus-4-6',1,1,0,0,''),('default','claude-opus-4-6',2,0,0,0,''),('default','claude-sonnet-4-6',1,1,0,0,'');
/*!40000 ALTER TABLE `abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channels`
--

DROP TABLE IF EXISTS `channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channels` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` bigint DEFAULT '0',
  `key` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `open_ai_organization` longtext COLLATE utf8mb4_general_ci,
  `test_model` longtext COLLATE utf8mb4_general_ci,
  `status` bigint DEFAULT '1',
  `name` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `weight` bigint unsigned DEFAULT '0',
  `created_time` bigint DEFAULT NULL,
  `test_time` bigint DEFAULT NULL,
  `response_time` bigint DEFAULT NULL,
  `base_url` varchar(191) COLLATE utf8mb4_general_ci DEFAULT '',
  `other` longtext COLLATE utf8mb4_general_ci,
  `balance` double DEFAULT NULL,
  `balance_updated_time` bigint DEFAULT NULL,
  `models` longtext COLLATE utf8mb4_general_ci,
  `group` varchar(64) COLLATE utf8mb4_general_ci DEFAULT 'default',
  `used_quota` bigint DEFAULT '0',
  `model_mapping` text COLLATE utf8mb4_general_ci,
  `status_code_mapping` varchar(1024) COLLATE utf8mb4_general_ci DEFAULT '',
  `priority` bigint DEFAULT '0',
  `auto_ban` bigint DEFAULT '1',
  `other_info` longtext COLLATE utf8mb4_general_ci,
  `tag` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `setting` text COLLATE utf8mb4_general_ci,
  `param_override` text COLLATE utf8mb4_general_ci,
  `header_override` text COLLATE utf8mb4_general_ci,
  `remark` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `channel_info` json DEFAULT NULL,
  `settings` longtext COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  KEY `idx_channels_name` (`name`),
  KEY `idx_channels_tag` (`tag`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channels`
--

LOCK TABLES `channels` WRITE;
/*!40000 ALTER TABLE `channels` DISABLE KEYS */;
INSERT INTO `channels` VALUES (1,1,'sk-xfiupcpNTruNeiHoEwQJH97zLjy3EimDoPPHQI9BiyuAZD2b','','',1,'xingke',0,1771153913,1772409200,1608,'https://api.tianhegongyuan.com','',0,0,'claude-sonnet-4-6,claude-opus-4-6','default',1988,'','',0,1,'','','{\"force_format\":false,\"thinking_to_content\":false,\"proxy\":\"\",\"pass_through_body_enabled\":false,\"system_prompt\":\"\",\"system_prompt_override\":false}',NULL,NULL,NULL,'{\"is_multi_key\": false, \"multi_key_mode\": \"random\", \"multi_key_size\": 0, \"multi_key_status_list\": null, \"multi_key_polling_index\": 0}','{\"allow_service_tier\":false,\"disable_store\":false,\"allow_safety_identifier\":false}'),(2,1,'sk-dxw5xeTBn88sG8eVQVoA1GINBTPECkOp2PCdOrZECG4qc6qs','','',2,'MG7',0,1772012487,1772409197,2430,'http://148.113.217.166:3000','',0,0,'claude-opus-4-6','default',6101,'','',0,1,'','','{\"force_format\":false,\"thinking_to_content\":false,\"proxy\":\"\",\"pass_through_body_enabled\":false,\"system_prompt\":\"\",\"system_prompt_override\":false}',NULL,NULL,NULL,'{\"is_multi_key\": false, \"multi_key_mode\": \"random\", \"multi_key_size\": 0, \"multi_key_status_list\": null, \"multi_key_polling_index\": 0}','{\"allow_service_tier\":false,\"disable_store\":false,\"allow_safety_identifier\":false}');
/*!40000 ALTER TABLE `channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkins`
--

DROP TABLE IF EXISTS `checkins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkins` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `checkin_date` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `quota_awarded` bigint NOT NULL,
  `created_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_checkin_date` (`user_id`,`checkin_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkins`
--

LOCK TABLES `checkins` WRITE;
/*!40000 ALTER TABLE `checkins` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_oauth_providers`
--

DROP TABLE IF EXISTS `custom_oauth_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_oauth_providers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `slug` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `icon` varchar(128) COLLATE utf8mb4_general_ci DEFAULT '',
  `enabled` tinyint(1) DEFAULT '0',
  `client_id` varchar(256) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `client_secret` varchar(512) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `authorization_endpoint` varchar(512) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `token_endpoint` varchar(512) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_info_endpoint` varchar(512) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `scopes` varchar(256) COLLATE utf8mb4_general_ci DEFAULT 'openid profile email',
  `user_id_field` varchar(128) COLLATE utf8mb4_general_ci DEFAULT 'sub',
  `username_field` varchar(128) COLLATE utf8mb4_general_ci DEFAULT 'preferred_username',
  `display_name_field` varchar(128) COLLATE utf8mb4_general_ci DEFAULT 'name',
  `email_field` varchar(128) COLLATE utf8mb4_general_ci DEFAULT 'email',
  `well_known` varchar(512) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `auth_style` bigint DEFAULT '0',
  `access_policy` text COLLATE utf8mb4_general_ci,
  `access_denied_message` varchar(512) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_custom_oauth_providers_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_oauth_providers`
--

LOCK TABLES `custom_oauth_providers` WRITE;
/*!40000 ALTER TABLE `custom_oauth_providers` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_oauth_providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `created_at` bigint DEFAULT NULL,
  `type` bigint DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_general_ci,
  `username` varchar(191) COLLATE utf8mb4_general_ci DEFAULT '',
  `token_name` varchar(191) COLLATE utf8mb4_general_ci DEFAULT '',
  `model_name` varchar(191) COLLATE utf8mb4_general_ci DEFAULT '',
  `quota` bigint DEFAULT '0',
  `prompt_tokens` bigint DEFAULT '0',
  `completion_tokens` bigint DEFAULT '0',
  `use_time` bigint DEFAULT '0',
  `is_stream` tinyint(1) DEFAULT NULL,
  `channel_id` bigint DEFAULT NULL,
  `channel_name` longtext COLLATE utf8mb4_general_ci,
  `token_id` bigint DEFAULT '0',
  `group` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `ip` varchar(191) COLLATE utf8mb4_general_ci DEFAULT '',
  `request_id` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '',
  `other` longtext COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  KEY `idx_logs_ip` (`ip`),
  KEY `idx_logs_request_id` (`request_id`),
  KEY `idx_created_at_id` (`id`,`created_at`),
  KEY `idx_user_id_id` (`user_id`,`id`),
  KEY `idx_logs_user_id` (`user_id`),
  KEY `idx_created_at_type` (`created_at`,`type`),
  KEY `idx_logs_username` (`username`),
  KEY `idx_logs_token_name` (`token_name`),
  KEY `idx_logs_token_id` (`token_id`),
  KEY `idx_logs_group` (`group`),
  KEY `index_username_model_name` (`model_name`,`username`),
  KEY `idx_logs_model_name` (`model_name`),
  KEY `idx_logs_channel_id` (`channel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES (1,1,1771153963,2,'','root','playground-default','claude-sonnet-4-5-20250929',143,35,12,4,1,1,NULL,0,'default','','20260215111239782826482BCTfeEqz','{\"admin_info\":{\"use_channel\":[\"1\"]},\"billing_source\":\"wallet\",\"cache_ratio\":0.1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":2926,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":1.5,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/pg/chat/completions\",\"user_group_ratio\":-1}'),(2,1,1771153970,2,'','root','playground-default','claude-sonnet-4-5-20250929',470,53,52,2,1,1,NULL,0,'default','','2026021511124838304707748KjIK59','{\"admin_info\":{\"use_channel\":[\"1\"]},\"billing_source\":\"wallet\",\"cache_ratio\":0.1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":1275,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":1.5,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/pg/chat/completions\",\"user_group_ratio\":-1}'),(3,1,1772012309,2,'','root','playground-default','claude-opus-4-6',333,8,25,4,1,1,NULL,0,'default','','20260225093825633533533Ix1gusQa','{\"admin_info\":{\"use_channel\":[\"1\"]},\"billing_source\":\"wallet\",\"cache_ratio\":0.1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":2991,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":2.5,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/pg/chat/completions\",\"user_group_ratio\":-1}'),(4,1,1772012366,2,'','root','playground-default','claude-sonnet-4-6',474,152,17,2,1,1,NULL,0,'default','','20260225093924761444579zam32J8E','{\"admin_info\":{\"use_channel\":[\"1\"]},\"billing_source\":\"wallet\",\"cache_ratio\":1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":1752,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":2,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/pg/chat/completions\",\"user_group_ratio\":-1}'),(5,1,1772012553,2,'模型测试','root','模型测试','claude-opus-4-6',258,23,16,2,0,2,NULL,0,'default','','','{\"admin_info\":{\"use_channel\":null},\"cache_ratio\":0.1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":-1000,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":2.5,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/v1/chat/completions\",\"user_group_ratio\":-1}'),(6,1,1772012583,2,'','root','playground-default','claude-opus-4-6-thinking',397,52,69,3,1,2,NULL,0,'default','','202602250943005879466153FYhQjuo','{\"admin_info\":{\"use_channel\":[\"2\"]},\"billing_source\":\"wallet\",\"cache_ratio\":0.1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":1809,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":1,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/pg/chat/completions\",\"user_group_ratio\":-1}'),(7,1,1772012593,2,'','root','playground-default','claude-opus-4-6-thinking',305,100,41,3,1,2,NULL,0,'default','','20260225094310470072255Ol9ldaph','{\"admin_info\":{\"use_channel\":[\"2\"]},\"billing_source\":\"wallet\",\"cache_ratio\":0.1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":2398,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":1,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/pg/chat/completions\",\"user_group_ratio\":-1}'),(8,1,1772012611,2,'','root','playground-default','claude-opus-4-6',1668,97,114,6,1,2,NULL,0,'default','','20260225094325855202861qxDR1nmp','{\"admin_info\":{\"use_channel\":[\"2\"]},\"billing_source\":\"wallet\",\"cache_ratio\":0.1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":1851,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":2.5,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/pg/chat/completions\",\"user_group_ratio\":-1}'),(9,1,1772012617,2,'','root','playground-default','claude-opus-4-6',930,217,31,2,1,2,NULL,0,'default','','20260225094335187735952wELdycGn','{\"admin_info\":{\"use_channel\":[\"2\"]},\"billing_source\":\"wallet\",\"cache_ratio\":0.1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":1751,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":2.5,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/pg/chat/completions\",\"user_group_ratio\":-1}'),(10,1,1772013231,2,'','root','playground-default','claude-opus-4-6',1148,254,41,3,1,2,NULL,0,'default','','20260225095347674930745z4RKXJaw','{\"admin_info\":{\"use_channel\":[\"2\"]},\"billing_source\":\"wallet\",\"cache_ratio\":0.1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":2293,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":2.5,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/pg/chat/completions\",\"user_group_ratio\":-1}'),(11,1,1772013254,2,'','root','playground-default','claude-opus-4-6',1653,301,72,4,1,2,NULL,0,'default','','20260225095410528905399Py36dCv5','{\"admin_info\":{\"use_channel\":[\"2\"]},\"billing_source\":\"wallet\",\"cache_ratio\":0.1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":2443,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":2.5,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/pg/chat/completions\",\"user_group_ratio\":-1}'),(12,1,1772409197,2,'模型测试','root','模型测试','claude-opus-4-6',258,23,16,2,0,2,NULL,0,'default','','','{\"admin_info\":{\"use_channel\":null},\"cache_ratio\":0.1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":-1000,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":2.5,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/v1/chat/completions\",\"user_group_ratio\":-1}'),(13,1,1772409200,2,'模型测试','root','模型测试','claude-sonnet-4-6',176,8,16,1,0,1,NULL,0,'default','','','{\"admin_info\":{\"use_channel\":null},\"cache_ratio\":1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":-1000,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":2,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/v1/chat/completions\",\"user_group_ratio\":-1}'),(14,1,1772409234,2,'','root','playground-default','claude-sonnet-4-6',256,8,24,1,1,1,NULL,0,'default','','20260301235353463866538U2es84Um','{\"admin_info\":{\"use_channel\":[\"1\"]},\"billing_source\":\"wallet\",\"cache_ratio\":1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":825,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":2,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/pg/chat/completions\",\"user_group_ratio\":-1}'),(15,1,1772410813,2,'','root','playground-default','claude-sonnet-4-6',312,36,24,2,1,1,NULL,0,'default','','202603020020113776046600DVevQCE','{\"admin_info\":{\"use_channel\":[\"1\"]},\"billing_source\":\"wallet\",\"cache_ratio\":1,\"cache_tokens\":0,\"completion_ratio\":5,\"frt\":1443,\"group_ratio\":1,\"model_price\":-1,\"model_ratio\":2,\"request_conversion\":[\"OpenAI Compatible\"],\"request_path\":\"/pg/chat/completions\",\"user_group_ratio\":-1}');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `midjourneys`
--

DROP TABLE IF EXISTS `midjourneys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `midjourneys` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `action` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mj_id` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `prompt` longtext COLLATE utf8mb4_general_ci,
  `prompt_en` longtext COLLATE utf8mb4_general_ci,
  `description` longtext COLLATE utf8mb4_general_ci,
  `state` longtext COLLATE utf8mb4_general_ci,
  `submit_time` bigint DEFAULT NULL,
  `start_time` bigint DEFAULT NULL,
  `finish_time` bigint DEFAULT NULL,
  `image_url` longtext COLLATE utf8mb4_general_ci,
  `video_url` longtext COLLATE utf8mb4_general_ci,
  `video_urls` longtext COLLATE utf8mb4_general_ci,
  `status` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `progress` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fail_reason` longtext COLLATE utf8mb4_general_ci,
  `channel_id` bigint DEFAULT NULL,
  `quota` bigint DEFAULT NULL,
  `buttons` longtext COLLATE utf8mb4_general_ci,
  `properties` longtext COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  KEY `idx_midjourneys_start_time` (`start_time`),
  KEY `idx_midjourneys_finish_time` (`finish_time`),
  KEY `idx_midjourneys_status` (`status`),
  KEY `idx_midjourneys_progress` (`progress`),
  KEY `idx_midjourneys_user_id` (`user_id`),
  KEY `idx_midjourneys_action` (`action`),
  KEY `idx_midjourneys_mj_id` (`mj_id`),
  KEY `idx_midjourneys_submit_time` (`submit_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `midjourneys`
--

LOCK TABLES `midjourneys` WRITE;
/*!40000 ALTER TABLE `midjourneys` DISABLE KEYS */;
/*!40000 ALTER TABLE `midjourneys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `models`
--

DROP TABLE IF EXISTS `models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `models` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `model_name` varchar(128) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `icon` varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tags` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `vendor_id` bigint DEFAULT NULL,
  `endpoints` text COLLATE utf8mb4_general_ci,
  `status` bigint DEFAULT '1',
  `sync_official` bigint DEFAULT '1',
  `created_time` bigint DEFAULT NULL,
  `updated_time` bigint DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `name_rule` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_model_name_delete_at` (`model_name`,`deleted_at`),
  KEY `idx_models_vendor_id` (`vendor_id`),
  KEY `idx_models_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `models`
--

LOCK TABLES `models` WRITE;
/*!40000 ALTER TABLE `models` DISABLE KEYS */;
/*!40000 ALTER TABLE `models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `options` (
  `key` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` VALUES ('CompletionRatio','{\n  \"gpt-4-all\": 2,\n  \"gpt-4-gizmo-*\": 2,\n  \"gpt-4o-gizmo-*\": 3,\n  \"gpt-image-1\": 8,\n  \"claude-sonnet-4-6\": 2,\n  \"claude-opus-4-6-thinking\": 2\n}'),('DemoSiteEnabled','false'),('EpayId','root'),('EpayKey','Uu8297666'),('MinTopUp','1'),('ModelPrice','{\n  \"black-forest-labs/flux-1.1-pro\": 0.04,\n  \"dall-e-3\": 0.04,\n  \"gpt-4-gizmo-*\": 0.1,\n  \"gpt-4o-mini-tts\": 0.3,\n  \"imagen-3.0-generate-002\": 0.03,\n  \"mj_blend\": 0.1,\n  \"mj_custom_zoom\": 0,\n  \"mj_describe\": 0.05,\n  \"mj_edits\": 0.1,\n  \"mj_high_variation\": 0.1,\n  \"mj_imagine\": 0.1,\n  \"mj_inpaint\": 0,\n  \"mj_low_variation\": 0.1,\n  \"mj_modal\": 0.1,\n  \"mj_pan\": 0.1,\n  \"mj_reroll\": 0.1,\n  \"mj_shorten\": 0.1,\n  \"mj_upload\": 0.05,\n  \"mj_upscale\": 0.05,\n  \"mj_variation\": 0.1,\n  \"mj_video\": 0.8,\n  \"mj_zoom\": 0.1,\n  \"sora-2\": 0.3,\n  \"sora-2-pro\": 0.5,\n  \"suno_lyrics\": 0.01,\n  \"suno_music\": 0.1,\n  \"swap_face\": 0.05\n}'),('ModelRatio','{\n  \"360GPT_S2_V9\": 0.8572,\n  \"360gpt-pro\": 0.8572,\n  \"360gpt-turbo\": 0.0858,\n  \"360gpt-turbo-responsibility-8k\": 0.8572,\n  \"360gpt2-pro\": 0.8572,\n  \"BLOOMZ-7B\": 0.273972602739726,\n  \"ERNIE-3.5-4K-0205\": 0.821917808219178,\n  \"ERNIE-3.5-8K\": 0.821917808219178,\n  \"ERNIE-3.5-8K-0205\": 1.643835616438356,\n  \"ERNIE-3.5-8K-1222\": 0.821917808219178,\n  \"ERNIE-4.0-8K\": 8.219178082191782,\n  \"ERNIE-Bot-8K\": 1.643835616438356,\n  \"ERNIE-Lite-8K-0308\": 0.2054794520547945,\n  \"ERNIE-Lite-8K-0922\": 0.547945205479452,\n  \"ERNIE-Speed-128K\": 0.273972602739726,\n  \"ERNIE-Speed-8K\": 0.273972602739726,\n  \"ERNIE-Tiny-8K\": 0.0684931506849315,\n  \"Embedding-V1\": 0.136986301369863,\n  \"NousResearch/Hermes-4-405B-FP8\": 0.8,\n  \"PaLM-2\": 1,\n  \"Qwen/Qwen3-235B-A22B-Instruct-2507\": 0.3,\n  \"Qwen/Qwen3-235B-A22B-Thinking-2507\": 0.6,\n  \"Qwen/Qwen3-Coder-480B-A35B-Instruct-FP8\": 0.8,\n  \"SparkDesk-v1.1\": 1.2858,\n  \"SparkDesk-v2.1\": 1.2858,\n  \"SparkDesk-v3.1\": 1.2858,\n  \"SparkDesk-v3.5\": 1.2858,\n  \"SparkDesk-v4.0\": 1.2858,\n  \"ada\": 10,\n  \"babbage\": 10,\n  \"babbage-002\": 0.2,\n  \"bge-large-en\": 0.136986301369863,\n  \"bge-large-zh\": 0.136986301369863,\n  \"chatglm_lite\": 0.1429,\n  \"chatglm_pro\": 0.7143,\n  \"chatglm_std\": 0.3572,\n  \"chatglm_turbo\": 0.3572,\n  \"chatgpt-4o-latest\": 2.5,\n  \"claude-3-5-haiku-20241022\": 0.5,\n  \"claude-3-5-sonnet-20240620\": 1.5,\n  \"claude-3-5-sonnet-20241022\": 1.5,\n  \"claude-3-7-sonnet-20250219\": 1.5,\n  \"claude-3-7-sonnet-20250219-thinking\": 1.5,\n  \"claude-3-haiku-20240307\": 0.125,\n  \"claude-3-opus-20240229\": 7.5,\n  \"claude-3-sonnet-20240229\": 1.5,\n  \"claude-haiku-4-5-20251001\": 0.5,\n  \"claude-opus-4-1-20250805\": 7.5,\n  \"claude-opus-4-20250514\": 7.5,\n  \"claude-opus-4-5-20251101\": 2.5,\n  \"claude-opus-4-6\": 2.5,\n  \"claude-opus-4-6-high\": 2.5,\n  \"claude-opus-4-6-low\": 2.5,\n  \"claude-opus-4-6-max\": 2.5,\n  \"claude-opus-4-6-medium\": 2.5,\n  \"claude-sonnet-4-20250514\": 1.5,\n  \"claude-sonnet-4-5-20250929\": 1.5,\n  \"code-davinci-edit-001\": 10,\n  \"command\": 0.5,\n  \"command-light\": 0.5,\n  \"command-light-nightly\": 0.5,\n  \"command-nightly\": 0.5,\n  \"command-r\": 0.25,\n  \"command-r-08-2024\": 0.075,\n  \"command-r-plus\": 1.5,\n  \"command-r-plus-08-2024\": 1.25,\n  \"curie\": 10,\n  \"davinci\": 10,\n  \"davinci-002\": 1,\n  \"deepseek-ai/DeepSeek-R1\": 0.8,\n  \"deepseek-ai/DeepSeek-R1-0528\": 0.8,\n  \"deepseek-ai/DeepSeek-V3-0324\": 0.8,\n  \"deepseek-ai/DeepSeek-V3.1\": 0.8,\n  \"deepseek-chat\": 0.135,\n  \"deepseek-coder\": 0.135,\n  \"deepseek-reasoner\": 0.275,\n  \"embedding-bert-512-v1\": 0.0715,\n  \"embedding_s1_v1\": 0.0715,\n  \"gemini-1.5-flash-latest\": 0.075,\n  \"gemini-1.5-pro-latest\": 1.25,\n  \"gemini-2.0-flash\": 0.05,\n  \"gemini-2.5-flash\": 0.15,\n  \"gemini-2.5-flash-lite-preview-06-17\": 0.05,\n  \"gemini-2.5-flash-lite-preview-thinking-*\": 0.05,\n  \"gemini-2.5-flash-preview-04-17\": 0.075,\n  \"gemini-2.5-flash-preview-04-17-nothinking\": 0.075,\n  \"gemini-2.5-flash-preview-04-17-thinking\": 0.075,\n  \"gemini-2.5-flash-preview-05-20\": 0.075,\n  \"gemini-2.5-flash-preview-05-20-nothinking\": 0.075,\n  \"gemini-2.5-flash-preview-05-20-thinking\": 0.075,\n  \"gemini-2.5-flash-thinking-*\": 0.075,\n  \"gemini-2.5-pro\": 0.625,\n  \"gemini-2.5-pro-exp-03-25\": 0.625,\n  \"gemini-2.5-pro-preview-03-25\": 0.625,\n  \"gemini-2.5-pro-thinking-*\": 0.625,\n  \"gemini-embedding-001\": 0.075,\n  \"gemini-robotics-er-1.5-preview\": 0.15,\n  \"glm-3-turbo\": 0.3572,\n  \"glm-4\": 7.143,\n  \"glm-4-0520\": 6.8493150684931505,\n  \"glm-4-air\": 0.0684931506849315,\n  \"glm-4-airx\": 0.684931506849315,\n  \"glm-4-alltools\": 6.8493150684931505,\n  \"glm-4-flash\": 0,\n  \"glm-4-long\": 0.0684931506849315,\n  \"glm-4-plus\": 3.4246575342465753,\n  \"glm-4v\": 3.4246575342465753,\n  \"glm-4v-plus\": 0.684931506849315,\n  \"gpt-3.5-turbo\": 0.25,\n  \"gpt-3.5-turbo-0125\": 0.25,\n  \"gpt-3.5-turbo-0613\": 0.75,\n  \"gpt-3.5-turbo-1106\": 0.5,\n  \"gpt-3.5-turbo-16k\": 1.5,\n  \"gpt-3.5-turbo-16k-0613\": 1.5,\n  \"gpt-3.5-turbo-instruct\": 0.75,\n  \"gpt-4\": 15,\n  \"gpt-4-0125-preview\": 5,\n  \"gpt-4-0613\": 15,\n  \"gpt-4-1106-preview\": 5,\n  \"gpt-4-1106-vision-preview\": 5,\n  \"gpt-4-32k\": 30,\n  \"gpt-4-32k-0613\": 30,\n  \"gpt-4-all\": 15,\n  \"gpt-4-gizmo-*\": 15,\n  \"gpt-4-turbo\": 5,\n  \"gpt-4-turbo-2024-04-09\": 5,\n  \"gpt-4-turbo-preview\": 5,\n  \"gpt-4-vision-preview\": 5,\n  \"gpt-4.1\": 1,\n  \"gpt-4.1-2025-04-14\": 1,\n  \"gpt-4.1-mini\": 0.2,\n  \"gpt-4.1-mini-2025-04-14\": 0.2,\n  \"gpt-4.1-nano\": 0.05,\n  \"gpt-4.1-nano-2025-04-14\": 0.05,\n  \"gpt-4.5-preview\": 37.5,\n  \"gpt-4.5-preview-2025-02-27\": 37.5,\n  \"gpt-4o\": 1.25,\n  \"gpt-4o-2024-05-13\": 2.5,\n  \"gpt-4o-2024-08-06\": 1.25,\n  \"gpt-4o-2024-11-20\": 1.25,\n  \"gpt-4o-all\": 15,\n  \"gpt-4o-audio-preview\": 1.25,\n  \"gpt-4o-audio-preview-2024-10-01\": 1.25,\n  \"gpt-4o-gizmo-*\": 2.5,\n  \"gpt-4o-mini\": 0.075,\n  \"gpt-4o-mini-2024-07-18\": 0.075,\n  \"gpt-4o-mini-realtime-preview\": 0.3,\n  \"gpt-4o-mini-realtime-preview-2024-12-17\": 0.3,\n  \"gpt-4o-realtime-preview\": 2.5,\n  \"gpt-4o-realtime-preview-2024-10-01\": 2.5,\n  \"gpt-4o-realtime-preview-2024-12-17\": 2.5,\n  \"gpt-5\": 0.625,\n  \"gpt-5-2025-08-07\": 0.625,\n  \"gpt-5-chat-latest\": 0.625,\n  \"gpt-5-mini\": 0.125,\n  \"gpt-5-mini-2025-08-07\": 0.125,\n  \"gpt-5-nano\": 0.025,\n  \"gpt-5-nano-2025-08-07\": 0.025,\n  \"gpt-image-1\": 2.5,\n  \"grok-2\": 1,\n  \"grok-2-vision\": 1,\n  \"grok-3-beta\": 1.5,\n  \"grok-3-fast-beta\": 2.5,\n  \"grok-3-mini-beta\": 0.15,\n  \"grok-3-mini-fast-beta\": 0.3,\n  \"grok-beta\": 2.5,\n  \"grok-vision-beta\": 2.5,\n  \"hunyuan\": 7.143,\n  \"llama-3-sonar-large-32k-chat\": 0,\n  \"llama-3-sonar-large-32k-online\": 0,\n  \"llama-3-sonar-small-32k-chat\": 0.1,\n  \"llama-3-sonar-small-32k-online\": 0.1,\n  \"o1\": 7.5,\n  \"o1-2024-12-17\": 7.5,\n  \"o1-mini\": 0.55,\n  \"o1-mini-2024-09-12\": 0.55,\n  \"o1-preview\": 7.5,\n  \"o1-preview-2024-09-12\": 7.5,\n  \"o1-pro\": 75,\n  \"o1-pro-2025-03-19\": 75,\n  \"o3\": 1,\n  \"o3-2025-04-16\": 1,\n  \"o3-deep-research\": 5,\n  \"o3-deep-research-2025-06-26\": 5,\n  \"o3-mini\": 0.55,\n  \"o3-mini-2025-01-31\": 0.55,\n  \"o3-mini-2025-01-31-high\": 0.55,\n  \"o3-mini-2025-01-31-low\": 0.55,\n  \"o3-mini-2025-01-31-medium\": 0.55,\n  \"o3-mini-high\": 0.55,\n  \"o3-mini-low\": 0.55,\n  \"o3-mini-medium\": 0.55,\n  \"o3-pro\": 10,\n  \"o3-pro-2025-06-10\": 10,\n  \"o4-mini\": 0.55,\n  \"o4-mini-2025-04-16\": 0.55,\n  \"o4-mini-deep-research\": 1,\n  \"o4-mini-deep-research-2025-06-26\": 1,\n  \"openai/gpt-oss-120b\": 0.5,\n  \"qwen-plus\": 10,\n  \"qwen-turbo\": 0.8572,\n  \"semantic_similarity_s1_v1\": 0.0715,\n  \"tao-8k\": 0.136986301369863,\n  \"text-ada-001\": 0.2,\n  \"text-babbage-001\": 0.25,\n  \"text-curie-001\": 1,\n  \"text-davinci-edit-001\": 10,\n  \"text-embedding-004\": 0.001,\n  \"text-embedding-3-large\": 0.065,\n  \"text-embedding-3-small\": 0.01,\n  \"text-embedding-ada-002\": 0.05,\n  \"text-embedding-v1\": 0.05,\n  \"text-moderation-latest\": 0.1,\n  \"text-moderation-stable\": 0.1,\n  \"text-search-ada-doc-001\": 10,\n  \"tts-1\": 7.5,\n  \"tts-1-1106\": 7.5,\n  \"tts-1-hd\": 15,\n  \"tts-1-hd-1106\": 15,\n  \"whisper-1\": 15,\n  \"yi-34b-chat-0205\": 0.18,\n  \"yi-34b-chat-200k\": 0.864,\n  \"yi-large\": 1.36986301369863,\n  \"yi-large-preview\": 1.36986301369863,\n  \"yi-large-rag\": 1.7123287671232876,\n  \"yi-large-rag-preview\": 1.7123287671232876,\n  \"yi-large-turbo\": 0.821917808219178,\n  \"yi-medium\": 0.17123287671232876,\n  \"yi-medium-200k\": 0.821917808219178,\n  \"yi-spark\": 0.0684931506849315,\n  \"yi-vision\": 0.410958904109589,\n  \"yi-vl-plus\": 0.432,\n  \"zai-org/GLM-4.5-FP8\": 0.8,\n  \"claude-sonnet-4-6\": 2,\n  \"claude-opus-4-6-thinking\": 1\n}'),('PayAddress',''),('Price','7'),('SelfUseModeEnabled','false'),('ServerAddress','https://token.xingke888.com'),('StripeApiSecret','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'),('StripeMinTopUp','1'),('StripePriceId','root123'),('StripeUnitPrice','7'),('StripeWebhookSecret','whsec_t83uobBIH6l3lrowR10ABWA5HPaiShZF');
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passkey_credentials`
--

DROP TABLE IF EXISTS `passkey_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `passkey_credentials` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `credential_id` varchar(512) COLLATE utf8mb4_general_ci NOT NULL,
  `public_key` text COLLATE utf8mb4_general_ci NOT NULL,
  `attestation_type` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `aa_guid` varchar(512) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sign_count` int unsigned DEFAULT '0',
  `clone_warning` tinyint(1) DEFAULT NULL,
  `user_present` tinyint(1) DEFAULT NULL,
  `user_verified` tinyint(1) DEFAULT NULL,
  `backup_eligible` tinyint(1) DEFAULT NULL,
  `backup_state` tinyint(1) DEFAULT NULL,
  `transports` text COLLATE utf8mb4_general_ci,
  `attachment` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `last_used_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_passkey_credentials_user_id` (`user_id`),
  UNIQUE KEY `idx_passkey_credentials_credential_id` (`credential_id`),
  KEY `idx_passkey_credentials_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passkey_credentials`
--

LOCK TABLES `passkey_credentials` WRITE;
/*!40000 ALTER TABLE `passkey_credentials` DISABLE KEYS */;
/*!40000 ALTER TABLE `passkey_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefill_groups`
--

DROP TABLE IF EXISTS `prefill_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prefill_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(32) COLLATE utf8mb4_general_ci NOT NULL,
  `items` json DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_time` bigint DEFAULT NULL,
  `updated_time` bigint DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prefill_name` (`name`),
  KEY `idx_prefill_groups_type` (`type`),
  KEY `idx_prefill_groups_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefill_groups`
--

LOCK TABLES `prefill_groups` WRITE;
/*!40000 ALTER TABLE `prefill_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefill_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quota_data`
--

DROP TABLE IF EXISTS `quota_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quota_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `username` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '',
  `model_name` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '',
  `created_at` bigint DEFAULT NULL,
  `token_used` bigint DEFAULT '0',
  `count` bigint DEFAULT '0',
  `quota` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_quota_data_user_id` (`user_id`),
  KEY `idx_qdt_model_user_name` (`model_name`,`username`),
  KEY `idx_qdt_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quota_data`
--

LOCK TABLES `quota_data` WRITE;
/*!40000 ALTER TABLE `quota_data` DISABLE KEYS */;
INSERT INTO `quota_data` VALUES (1,1,'root','claude-sonnet-4-5-20250929',1771153200,152,2,613),(2,1,'root','claude-opus-4-6',1772010000,1199,6,5990),(3,1,'root','claude-sonnet-4-6',1772010000,169,1,474),(4,1,'root','claude-opus-4-6-thinking',1772010000,262,2,702),(5,1,'root','claude-opus-4-6',1772406000,39,1,258),(6,1,'root','claude-sonnet-4-6',1772406000,56,2,432),(7,1,'root','claude-sonnet-4-6',1772409600,60,1,312);
/*!40000 ALTER TABLE `quota_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redemptions`
--

DROP TABLE IF EXISTS `redemptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redemptions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `key` char(32) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` bigint DEFAULT '1',
  `name` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `quota` bigint DEFAULT '100',
  `created_time` bigint DEFAULT NULL,
  `redeemed_time` bigint DEFAULT NULL,
  `used_user_id` bigint DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `expired_time` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_redemptions_key` (`key`),
  KEY `idx_redemptions_name` (`name`),
  KEY `idx_redemptions_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redemptions`
--

LOCK TABLES `redemptions` WRITE;
/*!40000 ALTER TABLE `redemptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `redemptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setups`
--

DROP TABLE IF EXISTS `setups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `setups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `initialized_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setups`
--

LOCK TABLES `setups` WRITE;
/*!40000 ALTER TABLE `setups` DISABLE KEYS */;
INSERT INTO `setups` VALUES (1,'v0.0.0',1771148517);
/*!40000 ALTER TABLE `setups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_orders`
--

DROP TABLE IF EXISTS `subscription_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `plan_id` bigint DEFAULT NULL,
  `money` double DEFAULT NULL,
  `trade_no` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` longtext COLLATE utf8mb4_general_ci,
  `create_time` bigint DEFAULT NULL,
  `complete_time` bigint DEFAULT NULL,
  `provider_payload` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trade_no` (`trade_no`),
  KEY `idx_subscription_orders_user_id` (`user_id`),
  KEY `idx_subscription_orders_plan_id` (`plan_id`),
  KEY `idx_subscription_orders_trade_no` (`trade_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_orders`
--

LOCK TABLES `subscription_orders` WRITE;
/*!40000 ALTER TABLE `subscription_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_plans`
--

DROP TABLE IF EXISTS `subscription_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_plans` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8mb4_general_ci NOT NULL,
  `subtitle` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '',
  `price_amount` decimal(10,6) NOT NULL DEFAULT '0.000000',
  `currency` varchar(8) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'USD',
  `duration_unit` varchar(16) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'month',
  `duration_value` bigint NOT NULL DEFAULT '1',
  `custom_seconds` bigint NOT NULL DEFAULT '0',
  `enabled` tinyint(1) DEFAULT '1',
  `sort_order` bigint DEFAULT '0',
  `stripe_price_id` varchar(128) COLLATE utf8mb4_general_ci DEFAULT '',
  `creem_product_id` varchar(128) COLLATE utf8mb4_general_ci DEFAULT '',
  `max_purchase_per_user` bigint DEFAULT '0',
  `upgrade_group` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '',
  `total_amount` bigint NOT NULL DEFAULT '0',
  `quota_reset_period` varchar(16) COLLATE utf8mb4_general_ci DEFAULT 'never',
  `quota_reset_custom_seconds` bigint DEFAULT '0',
  `created_at` bigint DEFAULT NULL,
  `updated_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_plans`
--

LOCK TABLES `subscription_plans` WRITE;
/*!40000 ALTER TABLE `subscription_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_pre_consume_records`
--

DROP TABLE IF EXISTS `subscription_pre_consume_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_pre_consume_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `request_id` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `user_subscription_id` bigint DEFAULT NULL,
  `pre_consumed` bigint NOT NULL DEFAULT '0',
  `status` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` bigint DEFAULT NULL,
  `updated_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_subscription_pre_consume_records_request_id` (`request_id`),
  KEY `idx_subscription_pre_consume_records_updated_at` (`updated_at`),
  KEY `idx_subscription_pre_consume_records_user_id` (`user_id`),
  KEY `idx_subscription_pre_consume_records_user_subscription_id` (`user_subscription_id`),
  KEY `idx_subscription_pre_consume_records_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_pre_consume_records`
--

LOCK TABLES `subscription_pre_consume_records` WRITE;
/*!40000 ALTER TABLE `subscription_pre_consume_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_pre_consume_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` bigint DEFAULT NULL,
  `updated_at` bigint DEFAULT NULL,
  `task_id` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `platform` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `group` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `channel_id` bigint DEFAULT NULL,
  `quota` bigint DEFAULT NULL,
  `action` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fail_reason` longtext COLLATE utf8mb4_general_ci,
  `submit_time` bigint DEFAULT NULL,
  `start_time` bigint DEFAULT NULL,
  `finish_time` bigint DEFAULT NULL,
  `progress` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `properties` json DEFAULT NULL,
  `private_data` json DEFAULT NULL,
  `data` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tasks_created_at` (`created_at`),
  KEY `idx_tasks_platform` (`platform`),
  KEY `idx_tasks_action` (`action`),
  KEY `idx_tasks_status` (`status`),
  KEY `idx_tasks_start_time` (`start_time`),
  KEY `idx_tasks_progress` (`progress`),
  KEY `idx_tasks_task_id` (`task_id`),
  KEY `idx_tasks_user_id` (`user_id`),
  KEY `idx_tasks_channel_id` (`channel_id`),
  KEY `idx_tasks_submit_time` (`submit_time`),
  KEY `idx_tasks_finish_time` (`finish_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `key` char(48) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` bigint DEFAULT '1',
  `name` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_time` bigint DEFAULT NULL,
  `accessed_time` bigint DEFAULT NULL,
  `expired_time` bigint DEFAULT '-1',
  `remain_quota` bigint DEFAULT '0',
  `unlimited_quota` tinyint(1) DEFAULT NULL,
  `model_limits_enabled` tinyint(1) DEFAULT NULL,
  `model_limits` varchar(1024) COLLATE utf8mb4_general_ci DEFAULT '',
  `allow_ips` varchar(191) COLLATE utf8mb4_general_ci DEFAULT '',
  `used_quota` bigint DEFAULT '0',
  `group` varchar(191) COLLATE utf8mb4_general_ci DEFAULT '',
  `cross_group_retry` tinyint(1) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tokens_key` (`key`),
  KEY `idx_tokens_name` (`name`),
  KEY `idx_tokens_deleted_at` (`deleted_at`),
  KEY `idx_tokens_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (1,1,'FrFCjCB9j7DRugERQ8gbAUCsL1p1CPN3q7WPwo8UHfm4cWkW',1,'token',1772012685,1772012685,-1,0,1,0,'','',0,'default',0,NULL);
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `top_ups`
--

DROP TABLE IF EXISTS `top_ups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `top_ups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `amount` bigint DEFAULT NULL,
  `money` double DEFAULT NULL,
  `trade_no` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `create_time` bigint DEFAULT NULL,
  `complete_time` bigint DEFAULT NULL,
  `status` longtext COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trade_no` (`trade_no`),
  KEY `idx_top_ups_user_id` (`user_id`),
  KEY `idx_top_ups_trade_no` (`trade_no`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top_ups`
--

LOCK TABLES `top_ups` WRITE;
/*!40000 ALTER TABLE `top_ups` DISABLE KEYS */;
INSERT INTO `top_ups` VALUES (1,1,1,7,'ref_bb05df2e756914fc8233118b872a83bcdbbe0a00','stripe',1772419242,0,'pending');
/*!40000 ALTER TABLE `top_ups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two_fa_backup_codes`
--

DROP TABLE IF EXISTS `two_fa_backup_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_fa_backup_codes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `code_hash` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `is_used` tinyint(1) DEFAULT NULL,
  `used_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_two_fa_backup_codes_deleted_at` (`deleted_at`),
  KEY `idx_two_fa_backup_codes_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_fa_backup_codes`
--

LOCK TABLES `two_fa_backup_codes` WRITE;
/*!40000 ALTER TABLE `two_fa_backup_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_fa_backup_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two_fas`
--

DROP TABLE IF EXISTS `two_fas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_fas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `secret` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `is_enabled` tinyint(1) DEFAULT NULL,
  `failed_attempts` bigint DEFAULT '0',
  `locked_until` datetime(3) DEFAULT NULL,
  `last_used_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_two_fas_user_id` (`user_id`),
  KEY `idx_two_fas_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_fas`
--

LOCK TABLES `two_fas` WRITE;
/*!40000 ALTER TABLE `two_fas` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_fas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_oauth_bindings`
--

DROP TABLE IF EXISTS `user_oauth_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_oauth_bindings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `provider_id` bigint NOT NULL,
  `provider_user_id` varchar(256) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_user_provider` (`user_id`,`provider_id`),
  UNIQUE KEY `ux_provider_userid` (`provider_id`,`provider_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_oauth_bindings`
--

LOCK TABLES `user_oauth_bindings` WRITE;
/*!40000 ALTER TABLE `user_oauth_bindings` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_oauth_bindings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_subscriptions`
--

DROP TABLE IF EXISTS `user_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_subscriptions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `plan_id` bigint DEFAULT NULL,
  `amount_total` bigint NOT NULL DEFAULT '0',
  `amount_used` bigint NOT NULL DEFAULT '0',
  `start_time` bigint DEFAULT NULL,
  `end_time` bigint DEFAULT NULL,
  `status` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `source` varchar(32) COLLATE utf8mb4_general_ci DEFAULT 'order',
  `last_reset_time` bigint DEFAULT '0',
  `next_reset_time` bigint DEFAULT '0',
  `upgrade_group` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '',
  `prev_user_group` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '',
  `created_at` bigint DEFAULT NULL,
  `updated_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_subscriptions_end_time` (`end_time`),
  KEY `idx_user_subscriptions_status` (`status`),
  KEY `idx_user_subscriptions_next_reset_time` (`next_reset_time`),
  KEY `idx_user_subscriptions_user_id` (`user_id`),
  KEY `idx_user_sub_active` (`user_id`,`status`,`end_time`),
  KEY `idx_user_subscriptions_plan_id` (`plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_subscriptions`
--

LOCK TABLES `user_subscriptions` WRITE;
/*!40000 ALTER TABLE `user_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `role` bigint DEFAULT '1',
  `status` bigint DEFAULT '1',
  `email` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `github_id` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `discord_id` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `oidc_id` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `wechat_id` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `telegram_id` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `access_token` char(32) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `quota` bigint DEFAULT '0',
  `used_quota` bigint DEFAULT '0',
  `request_count` bigint DEFAULT '0',
  `group` varchar(64) COLLATE utf8mb4_general_ci DEFAULT 'default',
  `aff_code` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `aff_count` bigint DEFAULT '0',
  `aff_quota` bigint DEFAULT '0',
  `aff_history` bigint DEFAULT '0',
  `inviter_id` bigint DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `linux_do_id` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `setting` text COLLATE utf8mb4_general_ci,
  `remark` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `stripe_customer` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `idx_users_access_token` (`access_token`),
  UNIQUE KEY `idx_users_aff_code` (`aff_code`),
  KEY `idx_users_we_chat_id` (`wechat_id`),
  KEY `idx_users_inviter_id` (`inviter_id`),
  KEY `idx_users_linux_do_id` (`linux_do_id`),
  KEY `idx_users_display_name` (`display_name`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_oidc_id` (`oidc_id`),
  KEY `idx_users_telegram_id` (`telegram_id`),
  KEY `idx_users_deleted_at` (`deleted_at`),
  KEY `idx_users_stripe_customer` (`stripe_customer`),
  KEY `idx_users_username` (`username`),
  KEY `idx_users_git_hub_id` (`github_id`),
  KEY `idx_users_discord_id` (`discord_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'root','$2a$10$bhH2UTCdh0qKAK2Qpl8PMOC0iaAHPfAqBUgnGmXtXCyBNoCNb.CsW','Root User',100,1,'','','','','','',NULL,99991911,8089,12,'default','qON1',0,0,0,0,NULL,'','','',''),(2,'aacockjt523','$2a$10$0C/m4z2KwxJxi1ufhANvWedpkQ8ccCsyNjZYFZfTWlQb1DwI8rmyG','aacockjt523',1,1,'','','','','','',NULL,0,0,0,'default','BV7N',0,0,0,0,NULL,'','{\"gotify_priority\":0,\"sidebar_modules\":\"{\\\"chat\\\":{\\\"chat\\\":true,\\\"enabled\\\":true,\\\"playground\\\":true},\\\"console\\\":{\\\"detail\\\":true,\\\"enabled\\\":true,\\\"log\\\":true,\\\"midjourney\\\":true,\\\"task\\\":true,\\\"token\\\":true},\\\"personal\\\":{\\\"enabled\\\":true,\\\"personal\\\":true,\\\"topup\\\":true}}\"}','','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendors`
--

DROP TABLE IF EXISTS `vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendors` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `icon` varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` bigint DEFAULT '1',
  `created_time` bigint DEFAULT NULL,
  `updated_time` bigint DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_vendor_name_delete_at` (`name`,`deleted_at`),
  KEY `idx_vendors_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendors`
--

LOCK TABLES `vendors` WRITE;
/*!40000 ALTER TABLE `vendors` DISABLE KEYS */;
INSERT INTO `vendors` VALUES (1,'Anthropic','','Claude.Color',1,1771153917,1771153917,NULL);
/*!40000 ALTER TABLE `vendors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-02 10:45:15
